document.getElementById('fileInput').addEventListener('change', function(event) {
    const fileList = document.getElementById('file-list');
    const files = event.target.files;

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const col = document.createElement('div');
        col.className = 'file-card';

        const fileContent = document.createElement('div');
        fileContent.className = 'file-content';

        if (file.type.startsWith('image/')) {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            fileContent.appendChild(img);
        } else {
            const icon = document.createElement('i');
            if (file.type === 'application/pdf') {
                icon.className = 'fas fa-file-pdf';
            } else if (
                file.type === 'application/msword' ||
                file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            ) {
                icon.className = 'fas fa-file-word';
            } else if (file.type === 'text/plain') {
                icon.className = 'fas fa-file-alt';
            } else {
                icon.className = 'fas fa-file';
            }
            fileContent.appendChild(icon);
        }

        const fileInfo = document.createElement('div');
        fileInfo.className = 'file-info';
        fileInfo.innerHTML =
            `<p>File Name: ${file.name}</p><p>File Size: ${(file.size / 1024).toFixed(2)} KB</p><p>File Type: ${file.type}</p>`;

        col.appendChild(fileContent);
        col.appendChild(fileInfo);
        fileList.appendChild(col);
    }
});